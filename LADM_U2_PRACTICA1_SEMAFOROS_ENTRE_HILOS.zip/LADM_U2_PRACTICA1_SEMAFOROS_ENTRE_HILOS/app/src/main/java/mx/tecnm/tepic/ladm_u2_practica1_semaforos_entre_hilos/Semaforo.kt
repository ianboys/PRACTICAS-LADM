package mx.tecnm.tepic.ladm_u2_practica1_semaforos_entre_hilos

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

var rojo = Color.argb(100,244,67,54)
var amarillo = Color.argb(100,255,235,59)
var verde = Color.argb(100,76,175,80)

class Semaforo(x : Float,y : Float, posicion : Boolean, carro1 : Carro, carro2 : Carro) {
    var posX = x
    var posY = y
    var lado = posicion
    var car1 = carro1
    var car2 = carro2

    var rojo1 = rojo
    var ama1 = amarillo
    var verde1 = verde

    var rojo2 = rojo
    var ama2 = amarillo
    var verde2 = verde

    var bandera = false

    fun dibujarSemaforo(c: Canvas, p: Paint){
        if (lado){
            //Semaforo calle Vertical
            var posX2 = posX+180f
            var posY2 = posY+490f

            p.color = Color.BLACK
            c.drawRect(posX,posY,posX2,posY2,p)

            //LUCES
            //Rojo
            p.color = rojo1
            c.drawCircle(posX+90f,posY+90f,65f,p)
            //Amarillo
            p.color = ama1
            c.drawCircle(posX+90f,posY+245f,65f,p)
            //Verde
            p.color = verde1
            c.drawCircle(posX+90f,posY+400f,65f,p)

        }else{
            //Semaforo calle horizontal
            var posX2 = posX+180f
            var posY2 = posY+490f

            p.color = Color.BLACK
            c.drawRect(posX,posY,posX2,posY2,p)

            //Luces
            //Rojo
            p.color = rojo2
            c.drawCircle(posX+90f,posY+90f,65f,p)
            //Amarillo
            p.color = ama2
            c.drawCircle(posX+90f,posY+245f,65f,p)
            //Verde
            p.color = verde2
            c.drawCircle(posX+90f,posY+400f,65f,p)

        }
        if (!bandera){
            ciclo()
            bandera = true
        }
    }

    fun ciclo(){
        var hiloSemaforo = HiloSemaforo(this)
        hiloSemaforo.start()
    }
}

class HiloSemaforo(semaforo: Semaforo) : Thread(){
    var sem = semaforo
    var contador = 0

    override fun run() {
        super.run()
        while (true){
            if (contador==0){
                rotSemaforo()
                contador=1
            }else if (contador==1){
                rotSemaforo()
                contador=2
            }else if (contador==2){
                rotSemaforo()
                contador=0
            }
            //println(contador)
            sleep(3000)
        }
    }

    fun rotSemaforo(){
        when(contador){
            0 -> {
                if (sem.lado){
                    println("prueba bbbbbbbbbbbbbbb")
                    sem.verde1 = Color.GREEN
                    sem.ama1 = amarillo
                    sem.rojo1 = rojo

                    sem.car1.alto = false
                    sem.car2.alto = false
                }else if (!sem.lado){
                    println("prueba aaaaaaaaaaaaaaa")
                    sem.rojo2 = Color.RED
                    sem.ama2 = amarillo
                    sem.verde2 = verde

                    sem.car1.alto = true
                    sem.car2.alto = true
                }
            }
            1 -> {
                if (sem.lado){
                    sem.verde1 = verde
                    sem.ama1 = Color.YELLOW
                    sem.rojo1 = rojo

                    sem.car1.alto = false
                    sem.car2.alto = false
                }else{
                    sem.rojo2 = rojo
                    sem.ama2 = Color.YELLOW
                    sem.verde2 = verde

                    sem.car1.alto = false
                    sem.car2.alto = false
                }
            }
            2 -> {
                if (sem.lado){
                    sem.rojo1 = Color.RED
                    sem.verde1 = verde
                    sem.ama1 = amarillo

                    sem.car1.alto = true
                    sem.car2.alto = true
                }else{
                    sem.verde2 = Color.GREEN
                    sem.rojo2 = rojo
                    sem.ama2 = amarillo

                    sem.car1.alto = false
                    sem.car2.alto = false
                }
            }
        }
    }
}