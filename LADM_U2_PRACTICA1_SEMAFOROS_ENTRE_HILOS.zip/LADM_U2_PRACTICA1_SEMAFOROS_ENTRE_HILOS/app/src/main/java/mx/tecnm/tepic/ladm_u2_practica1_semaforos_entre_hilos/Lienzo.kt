package mx.tecnm.tepic.ladm_u2_practica1_semaforos_entre_hilos

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class Lienzo (p:MainActivity) : View(p){
    //Carros Verticales
    var carroV = Carro(375f,200f,true,"ABAJO")
    var carroBl = Carro(600f, 1400f,true,"ARRIBA")

    //Carros horizontales
    var carroAz = Carro(100f,1030f,false,"DERECHA")
    var carroAm = Carro(850f,770f,false,"IZQUIERDA")

    //SEMAFOROS
    var semVer = Semaforo(70f,200f,true,carroV,carroBl)
    var semHor = Semaforo(800f,1250f,false,carroAz,carroAm)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)

        val p = Paint()

        //Calle vertical
        p.color = Color.GRAY
        c.drawRect(330f,0f,750f,2000f,p)

        p.color = Color.WHITE
        c.drawRect(525f,0f,550f,100f,p)
        c.drawRect(525f,200f,550f,300f,p)
        c.drawRect(525f,400f,550f,500f,p)
        c.drawRect(525f,600f,550f,700f,p)

        c.drawRect(525f,1200f,550f,1300f,p)
        c.drawRect(525f,1400f,550f,1500f,p)
        c.drawRect(525f,1600f,550f,1700f,p)
        c.drawRect(525f,1800f,550f,1900f,p)

        //Calle Horizontal
        p.color = Color.GRAY
        c.drawRect(0f,720f,1200f,1180f,p)

        p.color = Color.WHITE
        c.drawRect(0f,935f,100f,960f,p)
        c.drawRect(200f,935f,300f,960f,p)

        c.drawRect(800f,935f,900f,960f,p)
        c.drawRect(1000f,935f,1100f,960f,p)

        //CARROS
        carroV.dibujarCarro(c,p,Color.GREEN)
        carroBl.dibujarCarro(c,p,Color.WHITE)

        carroAz.dibujarCarro(c,p,Color.BLUE)
        carroAm.dibujarCarro(c,p,Color.YELLOW)

        //SEMAFOROS
        semVer.dibujarSemaforo(c,p)
        semHor.dibujarSemaforo(c,p)

        invalidate()
    }
}