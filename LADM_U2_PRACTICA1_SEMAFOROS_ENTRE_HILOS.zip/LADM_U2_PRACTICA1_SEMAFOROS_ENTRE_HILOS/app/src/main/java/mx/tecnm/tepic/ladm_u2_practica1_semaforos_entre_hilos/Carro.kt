package mx.tecnm.tepic.ladm_u2_practica1_semaforos_entre_hilos

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

class Carro (x : Float,y : Float, lado : Boolean, direccion : String){
    var posX = x
    var posY = y
    var lad = lado
    var dir = direccion
    var vel = (1..10).random().toFloat()
    private var bandera = false
    var alto = false

    fun dibujarCarro(c : Canvas, p: Paint, col : Int){
        if (lad){
            //Dibujar carro en calle vertical
            var posX2 = posX+100f
            var posY2 = posY +150f

            //Llantas
            var llX1 = posX-10f
            var llX2 = llX1+20f
            var llY1 = posY+20f
            var llY2 = llY1+30f

            //LLantas traseras
            p.color = Color.BLACK
            c.drawRect(llX1,llY1,llX2,llY2,p)
            c.drawRect(llX1+100f,llY1,llX2+100f,llY2,p)
            
            //Llantas delanteras
            c.drawRect(llX1,llY1+80f,llX2,llY2+80f,p)
            c.drawRect(llX1+100f,llY1+80f,llX2+100f,llY2+80f,p)

            //Carro
            p.color = col
            c.drawRect(posX,posY,posX2,posY2,p)

        }else{
            var posX2 = posX+150f
            var posY2 = posY +100f

            //LLantas
            var llX1 = posX+20f
            var llX2 = llX1+30f
            var llY1 = posY-10f
            var llY2 = llY1+20f

            //LLantas traseras
            p.color = Color.BLACK
            c.drawRect(llX1,llY1,llX2,llY2,p)
            c.drawRect(llX1,llY1+100f,llX2,llY2+100f,p)

            //Llantas delanteras
            c.drawRect(llX1+80f,llY1,llX2+80f,llY2,p)
            c.drawRect(llX1+80f,llY1+100f,llX2+80f,llY2+100f,p)

            //Carro
            p.color = col
            c.drawRect(posX,posY,posX2,posY2,p)
        }
        if (!bandera){
            bandera = true
            avanzar()
        }
    }

    fun avanzar(){
        var hiloCarro = HiloCarro(this)
        hiloCarro.start()
    }
}

class HiloCarro(carro: Carro) : Thread(){
    var car = carro
    override fun run() {
        super.run()
        while (true){
            movCarro()
            sleep(10)
        }
    }

    fun movCarro(){
        when(car.dir){
            "ABAJO" -> {
                if (car.posY>2000f){
                    car.posY = -150f
                }else if ((car.posY > 500 && car.posY <600) && car.alto){
                    return
                }else{
                    car.posY+= car.vel
                }
            }
            "ARRIBA" -> {
                if (car.posY<-150f){
                    car.posY = 2000f
                }else if ((car.posY > 1150f && car.posY < 1250f) && car.alto){
                    return
                }else{
                    car.posY-= car.vel
                }
            }
            "DERECHA" -> {
                if (car.posX>1100f){
                    car.posX = -150f
                }else if ((car.posX > 100f && car.posX <200f) && car.alto){
                    return
                }else{
                    car.posX+=car.vel
                }
            }
            "IZQUIERDA" -> {
                if (car.posX<-150f){
                    car.posX = 1200f
                }else if ((car.posX > 750f && car.posX < 800f) && car.alto){
                    return
                }else{
                    car.posX-=car.vel
                }
            }
        }
    }
}