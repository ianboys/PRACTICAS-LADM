package mx.tecnm.tepic.ladm_u2_practica2_juego_de_los_topos

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint

class Imagen(l : Lienzo, img : Int, posX : Float, posY : Float) {
    var x = posX
    var y = posY
    var imagen = BitmapFactory.decodeResource(l.resources,img)
    var lienzo = l

    fun pintar(c : Canvas){
        c.drawBitmap(imagen,x,y, Paint())
    }

    fun estaEnArea(toqueX : Float, toqueY : Float) : Boolean{
        var x2 = x+imagen.width
        var y2 = y+imagen.height

        if (toqueX >= x && toqueX <= x2){
            if (toqueY >= y && toqueY <= y2){
                return true
            }
        }
        return false
    }

}