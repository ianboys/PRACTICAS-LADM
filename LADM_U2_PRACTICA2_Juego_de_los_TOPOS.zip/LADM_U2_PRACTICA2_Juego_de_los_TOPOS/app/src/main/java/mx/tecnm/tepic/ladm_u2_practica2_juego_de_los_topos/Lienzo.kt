package mx.tecnm.tepic.ladm_u2_practica2_juego_de_los_topos

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View

class Lienzo(p:MainActivity) : View(p) {
    var arrayTopo = arrayOf(R.drawable.topo100,R.drawable.topo_golpeado)

    //Topos (descubierto y - 200f)
    var topo1 = Topo(this,arrayTopo,90f,550f,false)
    var topo2 = Topo(this,arrayTopo,460f,300f,false)
    var topo3 = Topo(this,arrayTopo,840f,550f,false)
    var topo4 = Topo(this,arrayTopo,1280f,300f,false)
    var topo5 = Topo(this,arrayTopo,1690f,550f,false)

    //Rocas
    var roca1 = Imagen(this,R.drawable.roca130,70f,550f)
    var roca2 = Imagen(this,R.drawable.roca130,440f,300f)
    var roca3 = Imagen(this,R.drawable.roca130,820f,550f)
    var roca4 = Imagen(this,R.drawable.roca130,1260f,300f)
    var roca5 = Imagen(this,R.drawable.roca130,1670f,550f)

    var fondo1 = Imagen(this,R.drawable.fondo6,100f,0f)
    var fondo2 = Imagen(this,R.drawable.fondo_tierra,0f,0f)
    var boton = Imagen(this,R.drawable.boton_play126,850f,500f)

    var pantalla = 0
    var puntuacion = 0
    var fallas = 0
    var velocidad = 0f

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val p = Paint()

        when(pantalla){
            0->{
                fondo1.pintar(c)
                p.textSize = 100f
                p.setColor(Color.YELLOW)
                c.drawText("Whac-A-Mole",750f,400f,p)
                boton.pintar(c)
            }
            //Nivel 1
            1->{
                fondo2.pintar(c)

                topo2.pintar(c)
                topo4.pintar(c)

                roca1.pintar(c)
                roca2.pintar(c)
                roca3.pintar(c)
                roca4.pintar(c)
                roca5.pintar(c)

                p.textSize = 70f
                p.setColor(Color.YELLOW)
                c.drawText("Nivel ${pantalla.toString()}",900f,80f,p)
                p.setColor(Color.WHITE)
                c.drawText("Puntos: ${puntuacion.toString()}",10f,80f,p)
                p.setColor(Color.RED)
                c.drawText("Fallas: ${fallas.toString()}",1800f,80f,p)
            }
            //Nivel 2
            2->{
                fondo2.pintar(c)

                topo2.pintar(c)
                topo3.pintar(c)
                topo4.pintar(c)

                roca1.pintar(c)
                roca2.pintar(c)
                roca3.pintar(c)
                roca4.pintar(c)
                roca5.pintar(c)

                p.textSize = 70f
                p.setColor(Color.YELLOW)
                c.drawText("Nivel ${pantalla.toString()}",900f,80f,p)
                p.setColor(Color.WHITE)
                c.drawText("Puntos: ${puntuacion.toString()}",10f,80f,p)
                p.setColor(Color.RED)
                c.drawText("Fallas: ${fallas.toString()}",1800f,80f,p)
            }
            //Nivel 3
            3->{
                fondo2.pintar(c)

                topo1.pintar(c)
                topo2.pintar(c)
                topo3.pintar(c)
                topo4.pintar(c)
                topo5.pintar(c)

                roca1.pintar(c)
                roca2.pintar(c)
                roca3.pintar(c)
                roca4.pintar(c)
                roca5.pintar(c)

                p.textSize = 70f
                p.setColor(Color.YELLOW)
                c.drawText("Nivel ${pantalla.toString()}",900f,80f,p)
                p.setColor(Color.WHITE)
                c.drawText("Puntos: ${puntuacion.toString()}",10f,80f,p)
                p.setColor(Color.RED)
                c.drawText("Fallas: ${fallas.toString()}",1800f,80f,p)
            }
            //Ganaste
            4->{
                fondo2.pintar(c)

                roca1.pintar(c)
                roca2.pintar(c)
                roca3.pintar(c)
                roca4.pintar(c)
                roca5.pintar(c)

                p.textSize = 70f
                p.setColor(Color.YELLOW)
                c.drawText("Nivel 3",900f,80f,p)
                p.setColor(Color.WHITE)
                c.drawText("Puntos: ${puntuacion.toString()}",10f,80f,p)
                p.setColor(Color.RED)
                c.drawText("Fallas: ${fallas.toString()}",1800f,80f,p)

                p.textSize = 150f
                p.setColor(Color.YELLOW)
                c.drawText("GANASTE",700f,450f,p)
            }
            5->{
                fondo2.pintar(c)

                roca1.pintar(c)
                roca2.pintar(c)
                roca3.pintar(c)
                roca4.pintar(c)
                roca5.pintar(c)

                p.textSize = 70f
                p.setColor(Color.WHITE)
                c.drawText("Puntos: ${puntuacion.toString()}",10f,80f,p)
                p.setColor(Color.RED)
                c.drawText("Fallas: ${fallas.toString()}",1800f,80f,p)

                p.textSize = 150f
                p.setColor(Color.RED)
                c.drawText("PERDISTE",700f,450f,p)
            }
        }
        if (fallas>=3 && pantalla !=4){
            pantalla = 5
        }
        invalidate()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when(e.action){
            MotionEvent.ACTION_DOWN ->{
                if (boton.estaEnArea(e.x,e.y) && pantalla == 0){
                    pantalla = 1
                    velocidad = 4f
                }
                //Nivel 1
                if (topo2.estaEnArea(e.x,e.y)  && topo2.estaAfuera() && topo2.golpe == false && pantalla == 1){
                    puntuacion++
                    topo2.golpe = true
                    if (puntuacion==3){
                        puntuacion=0
                        pantalla = 2
                        velocidad = 10f
                    }
                }else if (topo4.estaEnArea(e.x,e.y)  && topo4.estaAfuera() && topo4.golpe == false && pantalla == 1){
                    puntuacion++
                    topo4.golpe = true
                    if (puntuacion==3){
                        puntuacion=0
                        pantalla = 2
                        velocidad = 10f
                    }
                }
                //Nivel 2
                if (topo2.estaEnArea(e.x,e.y)  && topo2.estaAfuera() && topo2.golpe == false && pantalla == 2){
                    puntuacion++
                    topo2.golpe = true
                    if (puntuacion==5){
                        puntuacion=0
                        pantalla = 3
                        velocidad = 13f
                    }
                }else if (topo3.estaEnArea(e.x,e.y)  && topo3.estaAfuera() && topo3.golpe == false && pantalla == 2){
                    puntuacion++
                    topo3.golpe = true
                    if (puntuacion==5){
                        puntuacion=0
                        pantalla = 3
                        velocidad = 13f
                    }
                }else if (topo4.estaEnArea(e.x,e.y)  && topo4.estaAfuera() && topo4.golpe == false && pantalla == 2) {
                    puntuacion++
                    topo4.golpe = true
                    if (puntuacion == 5) {
                        puntuacion = 0
                        pantalla = 3
                        velocidad = 13f
                    }
                }
                //Nivel 3
                if (topo1.estaEnArea(e.x,e.y)  && topo1.estaAfuera() && topo1.golpe == false && pantalla == 3){
                    puntuacion++
                    topo1.golpe = true
                    if (puntuacion==8){
                        pantalla = 4
                    }
                }else if (topo2.estaEnArea(e.x,e.y)  && topo2.estaAfuera() && topo2.golpe == false && pantalla == 3){
                    puntuacion++
                    topo2.golpe = true
                    if (puntuacion==8){
                        pantalla = 4
                    }
                }else if (topo3.estaEnArea(e.x,e.y)  && topo3.estaAfuera() && topo3.golpe == false && pantalla == 3){
                    puntuacion++
                    topo3.golpe = true
                    if (puntuacion==8){
                        pantalla = 4
                    }
                }else if (topo4.estaEnArea(e.x,e.y)  && topo4.estaAfuera() && topo4.golpe == false && pantalla == 3) {
                    puntuacion++
                    topo4.golpe = true
                    if (puntuacion == 8) {
                        pantalla = 4
                    }
                }else if (topo5.estaEnArea(e.x,e.y)  && topo5.estaAfuera() && topo5.golpe == false && pantalla == 3) {
                    puntuacion++
                    topo5.golpe = true
                    if (puntuacion == 8) {
                        pantalla = 4
                    }
                }
            }
        }
        return true
    }
}