package mx.tecnm.tepic.ladm_u2_practica2_juego_de_los_topos

import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint

class Topo(l : Lienzo, arreglo : Array<Int>, posX : Float, posY : Float, golpeado : Boolean) {
    var x = posX
    var y = posY
    var golpe = golpeado

    var xOriginal = posX
    var yOriginal = posY

    var estado = arreglo
    var lienzo = l
    var imagen = BitmapFactory.decodeResource(l.resources,estado.get(0))
    var afuera = true
    private var bandera = false


    fun pintar(c : Canvas){
        c.drawBitmap(imagen,x,y, Paint())

        if (!bandera){
            bandera = true
            mover()
        }
    }

    fun estaEnArea(toqueX : Float, toqueY : Float) : Boolean{
        var x2 = x+imagen.width
        var y2 = y+imagen.height

        if (toqueX >= x && toqueX <= x2){
            if (toqueY >= y && toqueY <= y2){
                return true
            }
        }
        return false
    }

    fun estaAfuera() : Boolean{
        return afuera
    }

    fun mover(){
            var hiloTopo = HiloTopo(this)
            hiloTopo.start()
    }
}

class HiloTopo(to: Topo) : Thread(){
    var topo = to
    var tope = false
    var dormir = (50..100).random().toLong()
    override fun run() {
        super.run()
        while (true){
            if (topo.lienzo.fallas==3){
                return
            }
            if (topo.golpe == true){
                topo.imagen = BitmapFactory.decodeResource(topo.lienzo.resources,topo.estado.get(1))
            }
            if (!tope){
                topo.y-=topo.lienzo.velocidad
            }else{
                topo.y+=topo.lienzo.velocidad
            }

            if (topo.y>=topo.yOriginal){
                tope = false
                topo.afuera = true
                topo.golpe = false
                topo.imagen = BitmapFactory.decodeResource(topo.lienzo.resources,topo.estado.get(0))
            } else if (topo.y<=topo.yOriginal-200f){
                tope = true
                topo.afuera = false
                if (topo.golpe == false){
                    topo.lienzo.fallas++
                }
            }
            sleep(dormir)
        }
    }
}